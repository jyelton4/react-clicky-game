import React, { Component } from 'react';
// eslint-disable-next-line
import logo from './logo.svg';
// eslint-disable-next-line
import $ from 'jquery';
import './App.css';
import NavBar from "./components/NavBar";
import Banner from "./components/Banner";
import ImgBox from "./components/images/ImgBox";

class App extends Component {
  render() {
    return <div>
      <NavBar />
      <Banner />
      <ImgBox />
    </div>
  }
};

export default App;
