import React from "react";
import NavText from "./NavText";

const styles = {
  background: {
    background: "purple"
  }
}

const NavBar = () => {
  return <div className="navbar navbar-light bg-light justify-content-between row" style={styles.background}>
    <NavText pText="Clicky Game" />
    <NavText pText="Message" />
    <NavText pText="Score" />
  </div>  
};

export default NavBar;