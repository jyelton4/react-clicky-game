import React from "react";

const ImgBox = () => (
    <div className="row"></div>
);

export default ImgBox;